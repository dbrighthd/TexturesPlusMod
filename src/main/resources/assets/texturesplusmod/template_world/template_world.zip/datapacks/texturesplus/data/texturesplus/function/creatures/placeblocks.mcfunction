$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~-1 command_block{Command:"/execute positioned ~ ~1.5 ~ run function texturesplus:creatures/killsummon {\"entity\":\"$(entity)\",\"nbt\":\"$(nbt)\",\"silent\":$(silent)}"} replace
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~-1 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~1 $(block)
$execute positioned $(x) $(y) $(z) run fill ~ ~-1 ~1 ~ ~-1 ~$(gapsize) $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ stone_button[facing=south]
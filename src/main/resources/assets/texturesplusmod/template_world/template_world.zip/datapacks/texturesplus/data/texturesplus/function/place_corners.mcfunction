execute positioned 0 -55 0 run place template texturesplus:tplusworld_corner1
execute positioned -25 -55 0 run place template texturesplus:tplusworld_corner2
execute positioned -25 -55 -30 run place template texturesplus:tplusworld_corner3
execute positioned 0 -55 -30 run place template texturesplus:tplusworld_corner4
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~7 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~6 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~8 command_block{Command:"/item replace entity @p armor.chest with minecraft:elytra[minecraft:unbreakable={},minecraft:custom_name=\"$(rename)\"]"} replace
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~9 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~1 ~9 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~8 quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~8 stone_pressure_plate
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~1 ~8 {Silent:1,data:{slot:1},Tags:["generatedFrame"],Facing:2,Item:{id:"minecraft:elytra",count:1,components:{"minecraft:custom_name":"$(rename)"}},Invisible:1}
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~ ~8 {Silent:1,data:{slot:0},Tags:["generatedFrame"],Facing:2,Item:{id:"minecraft:elytra",count:1,components:{"minecraft:custom_name":"$(rename)","minecraft:damage":431}},Invisible:1}
$execute positioned $(x) $(y) $(z) align xz run summon minecraft:armor_stand ~0.5 ~2 ~9.5 {Silent:1,Tags:["generatedStand"],equipment: {chest: {id: "minecraft:elytra", count: 1, components: {"minecraft:custom_name": "$(rename)"}}},NoGravity:1,Invisible:1,Marker:1,Rotation:[0.0f,0.0f]}
execute at @s positioned ^ ^ ^-0.5 positioned ~ -57 ~ run function texturesplus:item_frame_states/getbarrelmacro with entity @s data
tag @s add show
tag @s remove hide
scoreboard objectives add awayTimer dummy
forceload add -1 -1 1 1
$execute positioned $(x) $(y) $(z) positioned ~ ~1 ~ run kill @e[type=item_frame,distance=..0.5]
$execute positioned $(x) $(y) $(z) align xz positioned ~1.5 ~1 ~0.5 run kill @e[type=armor_stand,distance=..0.5]


$execute positioned $(x) $(y) $(z) run setblock ~-1 ~-1 ~-1 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~ command_block{Command:"/item replace entity @p armor.head with minecraft:carved_pumpkin[minecraft:custom_name=\"$(rename)\"]"} replace
$execute positioned $(x) $(y) $(z) run setblock ~-1 ~ ~ $(block)
$execute positioned $(x) $(y) $(z) run setblock ~-1 ~1 ~ $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ stone_pressure_plate
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~1 ~ {Silent:1,data:{slot:0},Tags:["generatedFrame"],Facing:5,Item:{id:"minecraft:carved_pumpkin",count:1,components:{"minecraft:custom_name":"$(rename)"}},Invisible:1}
$execute positioned $(x) $(y) $(z) align xz run summon minecraft:armor_stand ~-0.5 ~1 ~0.5 {Silent:1,Tags:["generatedStand"],equipment: {head: {id: "minecraft:carved_pumpkin", count: 1, components: {"minecraft:custom_name": "$(rename)"}}},NoGravity:1,Invisible:1,Marker:1,Rotation:[-90.0f,0.0f]}
tp ~ ~-1.5 ~
tag @s add hide
tag @s remove show
scoreboard players set @s awayTimer 0
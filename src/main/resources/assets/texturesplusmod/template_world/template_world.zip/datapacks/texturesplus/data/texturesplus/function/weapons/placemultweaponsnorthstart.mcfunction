$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ minecraft:quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ minecraft:stone_pressure_plate
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~-1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~1 ~-1 ~-1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~ command_block[facing=down]{Command:"/execute as @p run function texturesplus:clearhotbar"} replace

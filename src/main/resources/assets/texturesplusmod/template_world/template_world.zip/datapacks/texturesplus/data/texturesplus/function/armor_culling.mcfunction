execute as @e[type=armor_stand,tag=!init,tag=!dontMove,tag=generatedStand] at @s run function texturesplus:states/init
execute as @a at @s as @e[type=armor_stand,distance=10..,tag=show,tag=generatedStand] at @s run function texturesplus:states/hide
execute as @a at @s as @e[type=armor_stand,distance=..10,tag=hide,tag=generatedStand] at @s run function texturesplus:states/show
execute as @e[type=minecraft:armor_stand,scores={awayTimer=..6},tag=hide,tag=generatedStand] run scoreboard players add @s awayTimer 1
execute as @e[type=minecraft:armor_stand,scores={awayTimer=5..},tag=hide,tag=generatedStand] run function texturesplus:clear_armorstand
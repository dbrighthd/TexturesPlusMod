data remove entity @s Item
tag @s add hide
tag @s remove show
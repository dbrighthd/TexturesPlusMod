$function texturesplus:placeelytrasouth {x:$(x),y:$(y),z:$(z),rename:"$(rename) Elytra",block:"$(block)"}
$function texturesplus:placeelytrapartialsouth {x:$(x),y:$(y),z:$(z),rename:"$(rename) Cape",block:"$(block)"}
$function texturesplus:placeelytrapartial2south {x:$(x),y:$(y),z:$(z),rename:"$(rename) Cape Elytra",block:"$(block)"}
$execute positioned $(x) $(y) $(z) positioned ~ ~ ~ run place template texturesplus:contributors_middle
$execute positioned $(x) $(y) $(z) positioned ~2 ~2 ~1 run setblock ~ ~ ~ minecraft:pale_oak_wall_sign[facing=east]{is_waxed:1b,has_glowing_text:0b,front_text:{messages:["$(message1_line1)","$(message1_line2)","$(message1_line3)","$(message1_line4)"],color:"$(message1_color)",has_glowing_text:1}}
$execute positioned $(x) $(y) $(z) positioned ~2 ~4 ~1 run setblock ~ ~ ~ minecraft:pale_oak_wall_sign[facing=east]{is_waxed:1b,has_glowing_text:0b,front_text:{messages:["$(contributor1_name)","$(contribution1_line2)","$(contribution1_line3)","$(contribution1_line4)"],color:"$(contribution1_color)",has_glowing_text:1}}
$execute positioned $(x) $(y) $(z) positioned ~2 ~3 ~1 run setblock ~ ~ ~ minecraft:player_wall_head[facing=east]{profile:{name:$(contributor1_mcname)}}



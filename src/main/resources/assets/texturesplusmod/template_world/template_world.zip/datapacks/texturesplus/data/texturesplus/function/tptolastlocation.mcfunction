tp @p @n[tag=playerLocation]
execute at @n[tag=playerLocation] run forceload remove ~ ~
execute as @e[tag=playerLocation] run kill @s
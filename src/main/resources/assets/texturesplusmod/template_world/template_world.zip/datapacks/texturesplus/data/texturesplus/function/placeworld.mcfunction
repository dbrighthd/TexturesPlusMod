execute at @p run summon armor_stand ~ ~ ~ {Tags:["playerLocation"],NoGravity:1,Invisible:1,Marker:1}
execute as @p at @s run tp @n[tag=playerLocation] ~ ~ ~ ~ ~
execute at @n[tag=playerLocation] run forceload add ~ ~
tp @a 0 -16 0
function texturesplus:place_corners

setblock 1 -55 9 minecraft:redstone_block
setblock 9 -55 -1 minecraft:redstone_block
setblock -1 -55 -9 minecraft:redstone_block
setblock -9 -55 1 minecraft:redstone_block
function texturesplus:allpumpkins
function texturesplus:allelytras
function texturesplus:allweapons
function texturesplus:allcreaturesblocks
function texturesplus:allcontributors
schedule function texturesplus:allcreatures 2t
summon minecraft:chicken -7 -16 -1 {Silent:1,NoAI:1,OnGround:1b,CustomName:"Cluckshroom",Rotation:[-90.0f,0.0f]}
summon minecraft:item_frame -7 -16 2 {Invisible:1,Facing:5,Item: {id: "minecraft:carved_pumpkin", count: 1, components: {"minecraft:unbreakable": {}, "minecraft:custom_name": "Black Red Headset"}}}
summon minecraft:armor_stand -7.0 -16 1.5 {NoGravity:1,Rotation:[90.0f,0.0f],equipment:{chest:{id:"minecraft:elytra",count:1,components:{"minecraft:custom_name":"Red Elytra"}}},attributes:[{id:"minecraft:scale",base:0.5}],Invisible:1,Tags:["dontMove"]}
summon minecraft:item_frame -7 -16 -2 {Invisible:1,Facing:5,Item: {id: "minecraft:netherite_sword", count: 1, components: {"minecraft:custom_name": "Red Lightsaber", "minecraft:enchantments": {"minecraft:sharpness": 1}}}}
setblock 6 -58 -10 minecraft:oak_planks
setblock 0 -54 -31 minecraft:quartz_pillar
setblock 0 -54 -27 minecraft:white_concrete
setblock -1 -54 -1 minecraft:white_concrete
setblock 0 -54 -1 minecraft:white_concrete
setblock 0 -54 0 minecraft:white_concrete
setblock -1 -54 0 minecraft:white_concrete
execute positioned 0 -16 0 run setworldspawn
function texturesplus:tptolastlocation
time set noon
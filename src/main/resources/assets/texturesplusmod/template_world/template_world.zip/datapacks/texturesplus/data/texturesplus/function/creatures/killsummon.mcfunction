execute positioned ~ ~ ~ run kill @e[type=!player,distance=..0.5]
$execute positioned ~ ~ ~ run summon $(entity) ~ ~ ~ {Silent:$(silent),NoAI:1,OnGround:1b,$(nbt)}
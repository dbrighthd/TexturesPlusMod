$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ minecraft:quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ minecraft:stone_pressure_plate
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~-1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~1 ~-1 ~-1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~1 ~-1 minecraft:$(special_block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~ command_block{Command:"/item replace entity @p weapon.mainhand with minecraft:$(item)[minecraft:custom_name=\"$(rename)\",minecraft:damage=$(damage)]"} replace
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~1 ~ {Silent:1,data:{slot:0},Tags:["generatedFrame"],Facing:3,Item:{id:"minecraft:$(item)",count:1,components:{"minecraft:custom_name":"$(rename)","minecraft:damage":$(damage)}},Invisible:1}
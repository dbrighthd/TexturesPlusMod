$execute positioned $(x) $(y) $(z) positioned ~ ~ ~ run place template texturesplus:contributors_start

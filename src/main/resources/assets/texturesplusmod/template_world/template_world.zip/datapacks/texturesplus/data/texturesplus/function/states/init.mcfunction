setblock ~ -56 ~ barrel
execute positioned ~ -56 ~ run item replace block ~ ~ ~ inventory.0 from entity @s armor.feet
execute positioned ~ -56 ~ run item replace block ~ ~ ~ inventory.1 from entity @s armor.legs
execute positioned ~ -56 ~ run item replace block ~ ~ ~ inventory.2 from entity @s armor.chest
execute positioned ~ -56 ~ run item replace block ~ ~ ~ inventory.3 from entity @s armor.head
tag @s add init
tag @s add show
$execute positioned $(x) $(y) $(z) run fill ~ ~-1 ~0 ~ ~-1 ~$(z_offset) minecraft:$(block)
$execute positioned $(x) $(y) $(z) run fill ~ ~-1 ~-1 ~$(x_offset) ~-1 ~-1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ minecraft:quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ minecraft:stone_pressure_plate
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~-1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~1 ~-1 minecraft:$(special_block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~ command_block{Command:"/item replace entity @p armor.$(slot) with minecraft:$(item)[minecraft:custom_name=\"$(rename)\",minecraft:damage=$(damage)]"} replace
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~1 ~ {Silent:1,data:{slot:0},Facing:3,Item:{id:"minecraft:$(item)",count:1,components:{"minecraft:custom_name":"$(rename)","minecraft:damage":$(damage)}},Invisible:1,Tags:["generatedFrame"]}
$execute positioned $(x) $(y) $(z) run summon minecraft:armor_stand ~ ~2 ~-1 {Silent:1,equipment:{$(slot):{id:"minecraft:$(item)",count:1,components:{"minecraft:custom_name":"$(rename)","minecraft:damage":$(damage)}}},Invisible:1,NoGravity:1,Marker:1,Tags:["generatedStand"]}
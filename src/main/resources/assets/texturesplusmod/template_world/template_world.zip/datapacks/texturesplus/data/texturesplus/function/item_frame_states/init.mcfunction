execute at @s positioned ^ ^ ^-0.5 run setblock ~ -57 ~ minecraft:barrel
execute at @s positioned ^ ^ ^-0.5 positioned ~ -57 ~ run function texturesplus:item_frame_states/setbarrelmacro with entity @s data
tag @s add init
tag @s add show
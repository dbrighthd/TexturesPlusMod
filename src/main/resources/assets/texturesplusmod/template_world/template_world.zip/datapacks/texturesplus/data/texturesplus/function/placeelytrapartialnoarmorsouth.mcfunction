$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~3 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~2 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~4 command_block{Command:"/item replace entity @p armor.chest with minecraft:elytra[minecraft:unbreakable={},minecraft:custom_name=\"$(rename)\"]"} replace
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~5 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~1 ~5 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~4 quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~4 stone_pressure_plate
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~1 ~4 {Silent:1,data:{slot:1},Tags:["generatedFrame"],Facing:2,Item:{id:"minecraft:elytra",count:1,components:{"minecraft:custom_name":"$(rename)"}},Invisible:1}
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~ ~4 {Silent:1,data:{slot:0},Tags:["generatedFrame"],Facing:2,Item:{id:"minecraft:elytra",count:1,components:{"minecraft:custom_name":"$(rename)","minecraft:damage":431}},Invisible:1}
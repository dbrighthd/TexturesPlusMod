execute if loaded -1 -54 -1 if loaded -1 -54 0 if loaded 0 -54 0 if loaded 0 -54 -1 unless block 6 -58 -10 minecraft:oak_planks run function texturesplus:placeworld
execute as @e[type=#minecraft:undead] run data merge entity @s {Fire:-10s}
execute if function texturesplus:armorsettings as @p if predicate texturesplus:ismoving run function texturesplus:armor_culling
execute if function texturesplus:itemframesettings as @p if predicate texturesplus:ismoving run function texturesplus:item_culling
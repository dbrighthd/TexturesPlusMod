$function texturesplus:placeelytranoarmorsouth {x:$(x),y:$(y),z:$(z),rename:"$(rename) Elytra",block:"$(block)"}
$function texturesplus:placeelytrapartialnoarmorsouth {x:$(x),y:$(y),z:$(z),rename:"$(rename) Cape",block:"$(block)"}
$function texturesplus:placeelytrapartial2noarmorsouth {x:$(x),y:$(y),z:$(z),rename:"$(rename) Cape Elytra",block:"$(block)"}
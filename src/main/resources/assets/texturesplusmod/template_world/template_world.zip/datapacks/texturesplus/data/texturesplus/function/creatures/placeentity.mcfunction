$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~-1 command_block{Command:"/execute positioned ~ ~1.5 ~ run function texturesplus:creatures/killsummon {\"entity\":\"$(entity)\",\"nbt\":\"$(nbt)\",\"silent\":$(silent)}"} replace
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~-1 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~1 $(block)
$execute positioned $(x) $(y) $(z) run fill ~ ~-1 ~1 ~ ~-1 ~$(gapsize) $(block)
$execute positioned $(x) $(y) $(z) positioned ~ ~1 ~-1 run summon $(entity) ~ ~ ~ {Silent:$(silent),Invulnerable:1,PersistenceRequired:1,NoAI:1,OnGround:1b,$(rawnbt)}
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ stone_button[facing=south]
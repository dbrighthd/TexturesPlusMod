
$execute positioned $(x) $(y) $(z) positioned ~ ~1 ~ run setblock ~ ~$(num) ~1 minecraft:$(special_block)
$execute positioned $(x) $(y) $(z) positioned ~ ~1 ~ run summon minecraft:item_frame ~ ~$(num) ~ {Silent:1,data:{slot:$(num)},Tags:["generatedFrame"],Facing:2,Item:{id:"minecraft:$(item)",count:1,components:{"minecraft:custom_name":"$(rename)","minecraft:damage":$(damage)}},Invisible:1}
$execute positioned $(x) $(y) $(z) positioned ~ ~-3 ~ run setblock ~ ~-$(num) ~ chain_command_block[facing=down]{auto:1,Command:"/item replace entity @p hotbar.$(num) with minecraft:$(item)[minecraft:custom_name=\"$(rename)\",minecraft:damage=$(damage)]"} replace

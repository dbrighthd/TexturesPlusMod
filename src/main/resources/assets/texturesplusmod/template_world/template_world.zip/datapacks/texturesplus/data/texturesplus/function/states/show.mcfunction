execute positioned ~ -56 ~ run item replace entity @s armor.feet from block ~ ~ ~ inventory.0
execute positioned ~ -56 ~ run item replace entity @s armor.legs from block ~ ~ ~ inventory.1
execute positioned ~ -56 ~ run item replace entity @s armor.chest from block ~ ~ ~ inventory.2
execute positioned ~ -56 ~ run item replace entity @s armor.head from block ~ ~ ~ inventory.3
tp ~ ~1.5 ~
tag @s add show
tag @s remove hide
scoreboard players set @s awayTimer 0
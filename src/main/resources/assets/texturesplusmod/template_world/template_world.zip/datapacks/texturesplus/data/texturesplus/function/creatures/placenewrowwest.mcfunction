$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ $(block)
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~-1 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~1 ~-1 ~1 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~2 ~-1 ~2 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~3 ~-1 ~3 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~4 ~-1 ~4 $(block)
$execute positioned $(x) $(y) $(z) run setblock ~5 ~-1 ~5 $(block)

$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~1 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~1 ~-1 ~2 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~2 ~-1 ~3 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~3 ~-1 ~4 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~4 ~-1 ~5 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~5 ~-1 ~6 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~6 ~-1 ~7 white_concrete
$execute positioned $(x) $(y) $(z) run setblock ~ ~-1 ~ minecraft:quartz_pillar
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~ minecraft:stone_pressure_plate
$execute positioned $(x) $(y) $(z) run setblock ~ ~ ~1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run setblock ~1 ~-1 ~1 minecraft:$(block)
$execute positioned $(x) $(y) $(z) run summon minecraft:item_frame ~ ~ ~ {Silent:1,data:{slot:10},Tags:["generatedFrame"],Facing:2,Item:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:custom_name":"$(enchantment)","minecraft:stored_enchantments":{"$(enchantment)":1}}},Invisible:1}
$execute positioned $(x) $(y) $(z) run setblock ~ ~-2 ~ command_block[facing=down]{Command:"/execute as @p run function texturesplus:clearhotbar"} replace
